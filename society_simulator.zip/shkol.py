# --- ШКОЛА ---
print("\n=== ДОБРО ПОЖАЛОВАТЬ В ШКОЛУ! ===")
for school_years in range(1, 13):
    print(f"\n--- ВОЗРАСТ: {age_years} | КЛАСС: {school_years} | СТАТЫ: {stats} ---")
    print("1-Усердная учеба(+5 INT), 2-Спорт(+5 STR), 3-Безделье")
    choice = input("> ")
    if choice == "1": stats["INT"] += 5
    elif choice == "2": stats["STR"] += 5
    age_years += 1
print("\n!!! ВЫ ВЗРОСЛЫЙ! ШКОЛА ОКОНЧЕНА.")